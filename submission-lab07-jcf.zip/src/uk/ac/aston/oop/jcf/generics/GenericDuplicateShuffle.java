package uk.ac.aston.oop.jcf.generics;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;


public class GenericDuplicateShuffle {

	public static void main(String[] args) {

        Random rnd = new Random();

        List<Object> l = new ArrayList<>();
        duplicate("A", 2, l);
        duplicate("B", 3, l);
        duplicate("C", 2, l);
        shuffle(rnd, l);
        System.out.println(l);

        List<Number> ln = new ArrayList<>();
        duplicate(1.0f, 3, ln);
        duplicate(1.5f, 5, ln);
        duplicate(5, 2, ln);
        shuffle(rnd, ln);
        System.out.println(ln);
    }

	
	
	public static <T> void shuffle(Random rnd, List<T> items) {
        for (int i = items.size() - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            T item = items.get(index);
            items.set(index, items.get(i));
            items.set(i, item);
        }
    }
	
	

	public static <T> void duplicate(T elem, int n, List<? super T> items) {
        for (int i = 0; i < n; i++) {
            items.add(elem);
        }
    }
    	
}
