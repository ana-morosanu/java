package uk.ac.aston.oop.calendar;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;


/**
 * The test class DayTest.
 *
 * @author (your name)
 * @version (a version number or a date)
 */


public class DayTest {

	@Test 
	public void appointmentStartOfDay() {
		//Arrange
		Day day = new Day(1); 
		Appointment app = new Appointment("meeting", 1);	
					
		//Act
		boolean success = day.makeAppointment(Day.START_OF_DAY, app);
		Appointment fetched = day.getAppointment(Day.START_OF_DAY);
					
		//Assert
		assertTrue(success, "Making an appointment at the start of a new day should work");
		assertSame(app, fetched, "It should be possible to fetch the appointment we just made");
	}
	
	@Test
	public void appointmentBeforeStartOfDay() {
	    // Arrange
	    Day day = new Day(1);
	    Appointment app = new Appointment("meeting", 1);
	
	    // Act
	    boolean success = day.makeAppointment(Day.START_OF_DAY - 1, app);
	    Appointment fetched = day.getAppointment(Day.START_OF_DAY - 1);
	
	
	    // Assert
	    assertFalse(success, "Making an appointment before the start of the day should fail");
	    assertNull(fetched, "No appointment should be made for an invalid time");
	}
	
	@Test
	public void twoAppsOnSameTime() {
	    // Arrange
	    Day day = new Day(1); 
	    Appointment appA = new Appointment("Appointment A", 1); 
	    Appointment appB = new Appointment("Appointment B", 1); 
	
	    // Act
	    boolean successA = day.makeAppointment(9, appA); 
	    Appointment fetchedA = day.getAppointment(9);
	    boolean successB = day.makeAppointment(9, appB); 
	    Appointment fetchedB = day.getAppointment(9);
	
	    // Assert
	    assertTrue(successA, "The first appointment should be successfully made");
	    assertSame(appA, fetchedA, "The first appointment should be correctly fetched");
	    assertFalse(successB, "No appointment should be made for the second appointment at the same time");
	    assertSame(appA, fetchedB, "The second attempt should not overwrite the first appointment");
	}
	
	@Test
	public void twoHourAppointmentAtStart() {
	    // Arrange
	    Day day = new Day(1); 
	    Appointment twoHourApp = new Appointment("2-hour meeting", 2); 
	
	    // Act
	    boolean success = day.makeAppointment(Day.START_OF_DAY, twoHourApp);
	    Appointment fetched9AM = day.getAppointment(Day.START_OF_DAY);
	    Appointment fetched10AM = day.getAppointment(Day.START_OF_DAY + 1);
	
	    // Assert
	    assertTrue(success, "A 2-hour appointment at the start of the day should be successfully made");
	    assertSame(twoHourApp, fetched9AM, "Fetching the appointment at 9 AM should return the 2-hour appointment");
	    assertSame(twoHourApp, fetched10AM, "Fetching the appointment at 10 AM should return the same 2-hour appointment");
	}
	
	@Test
	public void twoHourAppointmentBeyondEnd() {
	    // Arrange
	    Day day = new Day(1); 
	    Appointment twoHourApp = new Appointment("2-hour meeting", 2); 
	
	    // Act
	    boolean success = day.makeAppointment(Day.FINAL_APPOINTMENT_TIME - 1, twoHourApp); // Attempting to book at 4 PM
	    Appointment fetched5PM = day.getAppointment(Day.FINAL_APPOINTMENT_TIME - 1);
	    Appointment fetched6PM = day.getAppointment(Day.FINAL_APPOINTMENT_TIME);
	
	    // Assert
	    assertFalse(success, "A 2-hour appointment beyond the end of the day should not be successful");
	    assertNull(fetched5PM, "Fetching the appointment at 5 PM should return null");
	    assertNull(fetched6PM, "Fetching the appointment at 6 PM should return null");
	}
	
	
	@Test
	public void overlappingTwoHourAppointments() {
	    // Arrange
	    Day day = new Day(1); 
	    Appointment firstTwoHourApp = new Appointment("First 2-hour meeting", 2); 
	    Appointment overlappingTwoHourApp = new Appointment("Overlapping 2-hour meeting", 2);
	
	    // Act
	    boolean success1 = day.makeAppointment(Day.START_OF_DAY + 1, firstTwoHourApp); // Book from 10 AM to 12 PM
	    boolean success2 = day.makeAppointment(Day.START_OF_DAY, overlappingTwoHourApp); // Attempting to book from 9 AM to 11 AM
	
	    // Assert
	    assertTrue(success1, "The first 2-hour appointment should be successfully made");
	    assertFalse(success2, "An overlapping 2-hour appointment should not be successful");
	    assertNull(day.getAppointment(Day.START_OF_DAY), "Fetching the appointment at 9 AM should return null");
	    assertNull(day.getAppointment(Day.START_OF_DAY + 1), "Fetching the appointment at 10 AM should return null");
	}
}

