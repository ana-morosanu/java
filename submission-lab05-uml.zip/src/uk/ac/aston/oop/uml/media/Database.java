// Database.java
package uk.ac.aston.oop.uml.media;

import java.util.ArrayList;

public class Database {
    private ArrayList<Item> items;

    public Database() {
        items = new ArrayList<>();
    }

    public void addItem(Item i) {
        items.add(i);
    }

    public void print() {
        for (Item item : items) {
            System.out.println(item.toString());
        }
    }

    public static void main(String[] args) {
        // Create a Database, add items, and call print() in the main method
    }
}
