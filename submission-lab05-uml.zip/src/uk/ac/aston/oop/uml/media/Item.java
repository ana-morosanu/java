// Item.java
package uk.ac.aston.oop.uml.media;

public abstract class Item {
    private String title;
    private int playMinutes;
    private String comment = "";  // Explicitly initialize to an empty string
    private boolean owned;

    public Item(String title, int playMinutes) {
        this.title = title;
        this.playMinutes = playMinutes;
        this.owned = false;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String c) {
        comment = c;
    }

    public boolean isOwned() {
        return owned;
    }

    public void setOwned(boolean o) {
        owned = o;
    }

    public int getPlayMinutes() {
        return playMinutes;
    }

    @Override
    public String toString() {
        String ownership = owned ? "*" : "";
        return title + ": " + playMinutes + " - " + comment + ownership;
    }
}