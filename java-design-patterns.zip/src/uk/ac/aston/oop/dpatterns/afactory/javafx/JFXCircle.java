package uk.ac.aston.oop.dpatterns.afactory.javafx;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class JFXCircle extends Circle {
    private Circle circle;

    public JFXCircle(Group container, int cx, int cy, int radius) {
        this.circle = new Circle();
        this.circle.setCenterX(cx);
        this.circle.setCenterY(cy);
        this.circle.setRadius(radius);

        // Add the circle to the container's children
        container.getChildren().add(circle);
    }

    public void setFill(int r, int g, int b) {
        // Create JavaFX Color from RGB values
        Color color = Color.rgb(r, g, b);
        // Set fill color of the circle
        circle.setFill(color);
    }
}
