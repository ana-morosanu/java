package uk.ac.aston.oop.dpatterns.afactory;

public interface Circle {

	void setFill(int r, int g, int b);

}
