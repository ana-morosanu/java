package uk.ac.aston.oop.dpatterns.afactory;

public interface Drawing {

	void setFill(int r, int g, int b);

}
