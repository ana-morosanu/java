package uk.ac.aston.oop.dpatterns.singleton;

public class Player {

    private int dieFaces;

    public Player(int dieFaceCount) {
        this.dieFaces = dieFaceCount;
    }

    public int roll() {
        // Use the Singleton DiceRoller to get a random roll based on the dieFaces
        return DiceRoller.getInstance().roll(dieFaces);
    }

    public int getDieFaces() {
        return dieFaces;
    }
}
