package uk.ac.aston.oop.dpatterns.singleton;

import java.util.Random;

public class DiceRoller {

    private static DiceRoller instance = null;
    private static Long seed = null;
    private final Random random;  // Make random final

    private DiceRoller() {
        if (seed != null) {
            this.random = new Random(seed);
        } else {
            this.random = new Random();
        }
    }

    public static DiceRoller getInstance() {
        if (instance == null) {
            instance = new DiceRoller();
        }
        return instance;
    }

    public static void setSeed(long seed) {
        if (instance == null) {
            DiceRoller.seed = seed;
        } else {
            System.err.println("Seed cannot be set after DiceRoller instance is created.");
        }
    }

    public int roll(int faces) {
        // Return a random number between 1 and faces (both included)
        return random.nextInt(faces) + 1;
    }
}
