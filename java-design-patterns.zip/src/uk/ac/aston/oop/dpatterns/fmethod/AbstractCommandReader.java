package uk.ac.aston.oop.dpatterns.fmethod;

import java.util.Scanner;

public abstract class AbstractCommandReader {

    public void run() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter command (left, right, up, down, exit): ");
            String input = scanner.nextLine();

            if (processLine(input)) {
                break;  // Exit the loop if processLine returns true
            }
        }

        scanner.close();
    }

    protected abstract Runnable createMovementCommand(int dx, int dy);

    protected boolean processLine(String line) {
        switch (line.toLowerCase()) {
            case "left":
                createMovementCommand(-1, 0).run();
                return false;
            case "right":
                createMovementCommand(1, 0).run();
                return false;
            case "down":
                createMovementCommand(0, 1).run();
                return false;
            case "up":
                createMovementCommand(0, -1).run();
                return false;
            case "exit":
                return true;
            default:
                System.err.println("Unrecognized command: " + line);
                return false;
        }
    }
}