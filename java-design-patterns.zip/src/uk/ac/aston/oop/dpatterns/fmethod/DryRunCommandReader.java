package uk.ac.aston.oop.dpatterns.fmethod;

public class DryRunCommandReader extends AbstractCommandReader {

    @Override
    protected Runnable createMovementCommand(int dx, int dy) {
        String message = String.format("Move %d horizontally and %d vertically", dx, dy);
        return new DryRunCommand(message);
    }

    public static void main(String[] args) {
        // Example usage:
        DryRunCommandReader dryRunReader = new DryRunCommandReader();
        dryRunReader.run();
    }
}
