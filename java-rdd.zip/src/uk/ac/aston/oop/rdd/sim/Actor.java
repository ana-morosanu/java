// Step 7.1: Actor interface
package uk.ac.aston.oop.rdd.sim;

public interface Actor {
    GridCell getCell();
    void setCell(GridCell cell);
    Field getField();
    void setField(Field field);
    void act();
}

