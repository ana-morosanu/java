package uk.ac.aston.oop.rdd.sim;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GridCell {

    private final int row;
    private final int column;
    private final Grid grid;
    private final List<Animal> contents;

    public GridCell(int row, int column, Grid grid) {
        this.row = row;
        this.column = column;
        this.grid = grid;
        this.contents = new ArrayList<>();
    }

    
    public List<GridCell> getAdjacent() {
        List<GridCell> adjacentCells = new ArrayList<>();

        for (int i = row - 1; i <= row + 1; i++) {
            for (int j = column - 1; j <= column + 1; j++) {
                if (i == row && j == column) {
                    continue; 
                }

                if (isValidPosition(i, j)) {
                    adjacentCells.add(grid.get(i, j));
                }
            }
        }

        return adjacentCells;
    }

    
    
    public List<GridCell> getFreeAdjacent() {
        List<GridCell> freeAdjacentCells = new ArrayList<>();

        for (GridCell adjacentCell : getAdjacent()) {
            if (adjacentCell.getContents().isEmpty()) {
                freeAdjacentCells.add(adjacentCell);
            }
        }

        return freeAdjacentCells;
    }

    
    
    public GridCell getRandomFreeAdjacent(Random rnd) {
        List<GridCell> freeAdjacentCells = getFreeAdjacent();

        if (freeAdjacentCells.isEmpty()) {
            return null;
        }

        int randomIndex = rnd.nextInt(freeAdjacentCells.size());
        return freeAdjacentCells.get(randomIndex);
    }

    private boolean isValidPosition(int i, int j) {
        return i >= 0 && i < grid.getHeight() && j >= 0 && j < grid.getWidth();
    }

    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }

    public Grid getGrid() {
        return grid;
    }

    public List<Animal> getContents() {
        return contents;
    }
}
